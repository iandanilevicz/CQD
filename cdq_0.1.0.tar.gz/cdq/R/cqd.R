

#' @title Conditional Quantile Difference
#'
#' @description
#' Estimate the conditional quantile difference.
#'
#' @param xnew A matrix of new covariate values (each column is a covariate).
#' @param beta_low A matrix of lower quantile beta coefficients (e.g., 0.25 percentile); rows are bootstrap iterations.
#' @param beta_up A matrix of upper quantile beta coefficients (e.g., 0.75 percentile); rows are bootstrap iterations.
#' @param col Integer index of the column in \code{xnew} to display on the x-axis.
#' @param xlab Title for the x-axis.
#' @param ylab Title for the y-axis.
#' @param main Main title for the plot.
#' @param plot Logical; if \code{TRUE}, displays the plot.
#' @param alpha Significance level (default = 0.05), used for confidence interval bounds.
#' @param lwd Line width for the median CIQR line.
#'
#' @return A matrix with the following columns:
#' \describe{
#'   \item{x}{Values of the covariate specified in \code{col}.}
#'   \item{median CIQR}{Median conditional interquartile range.}
#'   \item{lower CI}{Lower bound of the confidence interval.}
#'   \item{upper CI}{Upper bound of the confidence interval.}
#' }
#'
#' @importFrom graphics lines polygon
#' @importFrom stats quantile
#' @importFrom quantreg rq
#'
#' @export
cqd = function(xnew, beta_low, beta_up, col=1, xlab="x", ylab="CIQR", main="", plot=TRUE, alpha=0.05, lwd = 1){
  delta = beta_up - beta_low
  if(is.vector(xnew)==TRUE){
    n = length(xnew)
    p = 1
    x = xnew
    y = matrix(0, ncol = 3, nrow = n)
    for(i in 1:n){
      point = delta * xnew[i]
      y[i,1] = quantile(point,(alpha/2))
      y[i,2] = quantile(point,0.5)
      y[i,3] = quantile(point,(1-alpha/2))
    }
  }else{
    n = dim(xnew)[1]
    p = dim(xnew)[2]
    x = xnew[,col]
    y = matrix(0, ncol = 3, nrow = n)
    for(i in 1:n){
      point = delta %*% xnew[i,]
      y[i,1] = quantile(point,(alpha/2))
      y[i,2] = quantile(point,0.5)
      y[i,3] = quantile(point,(1-alpha/2))
    }
  }
  if(plot==TRUE){
    plot(x,c(min(y),rep(max(y),n-1)), xlab=xlab, ylab=ylab, type="n", main=main)
    polygon(c(x,x[n:1]), c(y[,1],y[n:1,3]), col="gray90", border = NA)
    lines(x,y[,2], lwd=lwd)
  }
  xy = matrix(0, ncol = 4, nrow = n)
  xy[,1] = x
  xy[,2] = y[,2]
  xy[,3] = y[,1]
  xy[,4] = y[,3]
  colnames(xy) = c("x", "median CQD", "lower CI", "upper CI")
  return(xy)
}




#' @title Bootstrap function
#'
#' @description Edited from cqd function to include an additional argument for whether the specification is linear or quadratic
#'
#' @param xdat a matrix
#' @param ydat a vector
#' @param spec a character to determine if the model is linear or quadratic (spec=c("linear", "quadratic"))
#'
#' @return a list
#'
#' @export
boot_cond_qr<-function(xdat, ydat, spec){

  mini<-data.frame(x=xdat, y=ydat)

  B = 200

  if(spec=="linear"){
    n_col=2
  }

  if(spec=="quadratic"){
    n_col=3
  }

  beta01 = matrix(0, ncol = n_col, nrow=B)
  beta10 = matrix(0, ncol = n_col, nrow=B)
  beta25 = matrix(0, ncol = n_col, nrow=B)
  beta75 = matrix(0, ncol = n_col, nrow=B)
  beta90 = matrix(0, ncol = n_col, nrow=B)
  beta99 = matrix(0, ncol = n_col, nrow=B)

  for(i in 1:B){
    n = dim(mini)[1]
    n1 = sample(n, size=n, replace = TRUE)
    mini_boot = mini[n1,]

    if(spec=="linear"){
      mod = rq(mini_boot$y ~ mini_boot$x, tau = c(0.01, 0.1, 0.25, 0.75, 0.9, 0.99))
    }

    if(spec=="quadratic"){
      mini_boot$x2<-mini_boot$x^2
      mod = rq(mini_boot$y ~ mini_boot$x+mini_boot$x2, tau = c(0.01, 0.1, 0.25, 0.75, 0.9, 0.99))
    }

    beta01[i,] = mod$coefficients[,1]
    beta10[i,] = mod$coefficients[,2]
    beta25[i,] = mod$coefficients[,3]
    beta75[i,] = mod$coefficients[,4]
    beta90[i,] = mod$coefficients[,5]
    beta99[i,] = mod$coefficients[,6]
  }

  return(list(beta01=beta01, beta10=beta10, beta25=beta25, beta75=beta75, beta90=beta90, beta99=beta99))
}
